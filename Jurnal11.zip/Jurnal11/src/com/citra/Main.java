package com.citra;

public class Main {

    public static void main(String[] args) {
	BST<Character> pohon = new BST<>();

    pohon.tambahNode('F');
    pohon.tambahNode('E');
    pohon.tambahNode('H');
    pohon.tambahNode('D');
    pohon.tambahNode('G');
    pohon.tambahNode('C');
    pohon.tambahNode('B');
    pohon.tambahNode('H');
    pohon.tambahNode('K');
    pohon.tambahNode('J');

    System.out.printf("%n%n Pre-order Traversal; %n");
    pohon.preorderTraversal();
    System.out.printf("%n%n In-order Traversal; %n");
    pohon.inorderTraversal();
    System.out.printf("%n%n Post-order Traversal; %n");
    pohon.postorderTraversal();
    System.out.println();
    pohon.pencarianBST('K');
    pohon.pencarianBST('A');
    }
}
