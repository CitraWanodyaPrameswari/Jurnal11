package com.citra;

public class BST<E extends Comparable<E>> {
    private Tree<E> root;

    public BST() {
        root = null;
    }

    public void tambahNode(E tambahData) {
        if (root == null) {
            root = new Tree<E>(tambahData);
        } else {
            root.tambah(tambahData);
        }
    }

    public void preorderTraversal() {preorderSystem(root);}

    private void preorderSystem(Tree<E> node) {
        if (node == null) {
            return;
        }
        System.out.printf("%s", node.getData());
        preorderSystem(node.getLeftNode());
        preorderSystem(node.getRightNode());
    }

    public void inorderTraversal() {inorderSystem(root);}

    private void inorderSystem(Tree<E> node) {
        if (node == null) {
            return;
        }
        inorderSystem(node.getLeftNode());
        System.out.printf("%s", node.getData());
        inorderSystem(node.getRightNode());
    }
    public void postorderTraversal() {postorderSystem(root);}
    private void postorderSystem(Tree<E> node) {
        if (node == null) {
            return;
        }
        postorderSystem(node.getLeftNode());
        postorderSystem(node.getRightNode());
        System.out.printf("%s", node.getData());
    }

    public void pencarianBST(E key) {
        boolean result = resultpencarianBST(root, key);
        if (result) {
            System.out.println("Data berhasil ditemukan");
        } else {
            System.out.println("Data tidak ditemukan");
        }
    }

    private boolean resultpencarianBST(Tree<E> node, E key) {
        boolean value = false;
        if (node != null) {
            if (key.equals(node.getData()))
                value = true;
            else if (key.compareTo(node.getData()) < 0)
                value = resultpencarianBST(node.getLeftNode(), key);
            else
                value = resultpencarianBST(node.getRightNode(), key);
        }
        return value;
    }
}