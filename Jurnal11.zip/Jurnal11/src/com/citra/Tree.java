package com.citra;

public class Tree<E extends Comparable<E>> {
    private Tree<E> leftNode;
    protected E data;
    private Tree<E> rightNode;

    public Tree(E jumlahData){
        data = jumlahData;
        leftNode = rightNode = null;
    }

    public E getData(){return data; }
    public Tree<E> getLeftNode(){return leftNode; }
    public Tree<E> getRightNode(){return rightNode; }

    public void tambah(E tambahData){
        if(tambahData.compareTo(data) < 0){
            if(leftNode == null){
                leftNode = new Tree<E>(tambahData);
            }else{
                leftNode.tambah(tambahData);
            }
        }else if(tambahData.compareTo(data) > 0){
            if(rightNode == null){
                rightNode = new Tree<E>(tambahData);
            }else{
                rightNode.tambah(tambahData);
            }
        }
    }
}